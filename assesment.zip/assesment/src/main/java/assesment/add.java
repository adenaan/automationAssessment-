package assesment;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;


public class add {

	public static WebDriver driver;
	public static void main(String[] args) {
				
		
		System.setProperty("webdriver.chrome.driver", " C:\\webdriver\\chromedriver.exe");

		WebDriver driver = new ChromeDriver();
		
		
		// To Run in Edge browser
		//System.setProperty("webdriver.edge.driver", "C:\\webdriver\\msedgedriver.exe");

		// Start Edge Session
		//WebDriver driver = new EdgeDriver();

		// Open URL
		driver.get("https://beta.warrenroman.com/project-rocket-raccoon/home");
		
		// Maximize window
		driver.manage().window().maximize();
		
		// Click the add button
		Pageobjects.btn_add(driver).click();
		
		// wait for popup to load
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		
		// Enter in the information
		Pageobjects.txt_title(driver).sendKeys("Test");
		Pageobjects.txt_description(driver).sendKeys("Description info");
		
		//Click Submit
		Pageobjects.btn_submit(driver).click();
		
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		
		
		driver.quit();

	}

}
