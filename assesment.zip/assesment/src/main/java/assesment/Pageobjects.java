package assesment;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Pageobjects {
	
	
	private static WebElement element = null;
	
	//Button add

	public static WebElement btn_add(WebDriver driver){

		element = driver.findElement(By.xpath("//html/body/div[1]/div[1]/div[2]/a"));
		return element;
	}
	
	// Text box title
	public static WebElement txt_title(WebDriver driver){

		element = driver.findElement(By.id("staticEmail"));
		return element;
	}
	
	// Text box description
	public static WebElement txt_description(WebDriver driver){

		element = driver.findElement(By.xpath("//*[@id=\"myModal\"]/div/div/div[2]/form/div[2]/div/textarea"));
		return element;
	}
	
	// submit button
	public static WebElement btn_submit(WebDriver driver){

		element = driver.findElement(By.xpath("//*[@id=\"myModal\"]/div/div/div[2]/form/div[3]/div/div/div[1]/input"));
		return element;
	}
	
	// Title label
	public static WebElement lbl_titlename(WebDriver driver){

		element = driver.findElement(By.xpath("/html/body/div[1]/div[2]/div/div/div/div[9]/div[1]"));
		return element;
	}
	
	// Edit button
	public static WebElement btn_edit(WebDriver driver){

		element = driver.findElement(By.xpath("/html/body/div[1]/div[2]/div/div/div/div[9]/div[3]/a"));
		return element;
	}

}
