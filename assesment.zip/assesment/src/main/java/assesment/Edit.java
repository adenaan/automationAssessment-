package assesment;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Edit {
	
	public static WebDriver driver;

	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver", " C:\\webdriver\\chromedriver.exe");

		WebDriver driver = new ChromeDriver();
		
		
		//System.setProperty("webdriver.firefox.marionette", "C:\\webdriver\\geckodriver.exe");
		//driver = new FirefoxDriver();
		
		//System.setProperty("webdriver.edge.driver", "C:\\webdriver\\msedgedriver.exe");

		// Start Edge Session
		//WebDriver driver = new EdgeDriver();
		
		// Open URL
				driver.get("https://beta.warrenroman.com/project-rocket-raccoon/home");
				
		// Maximize window
		driver.manage().window().maximize();
		
		// Click Edit
		Pageobjects.btn_edit(driver).click();
		
		// Clear Title
		Pageobjects.txt_title(driver).clear();
		// Enter new title
		Pageobjects.txt_title(driver).sendKeys("New Test");
		
		//Clear description
		Pageobjects.txt_description(driver).clear();
		// Enter new description
		Pageobjects.txt_description(driver).sendKeys("New description");
		
		
		//Click the submit
		Pageobjects.btn_submit(driver).click();

	}

}
